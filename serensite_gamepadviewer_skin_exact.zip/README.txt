This package contains the exact Serensite controller PNG supplied/generated, without any additional cropping or background processing.
